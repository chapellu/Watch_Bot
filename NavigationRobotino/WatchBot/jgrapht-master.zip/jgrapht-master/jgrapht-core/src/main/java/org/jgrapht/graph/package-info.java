/**
 * Implementations of various graphs.
 */
package org.jgrapht.graph;
