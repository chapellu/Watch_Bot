/**
 * Utility classes for managing extensions/encapsulations.
 */
package org.jgrapht.alg.util.extension;
